'use strict';

// ------------------------------------------------------------------
// APP INITIALIZATION
// ------------------------------------------------------------------

const { App } = require('jovo-framework');
const { Alexa } = require('jovo-platform-alexa');
const { GoogleAssistant } = require('jovo-platform-googleassistant');
const { JovoDebugger } = require('jovo-plugin-debugger');
const { FileDb } = require('jovo-db-filedb');
const requestPromise = require('request-promise-native');
const app = new App();

app.use(
    new Alexa(),
    new GoogleAssistant(),
    new JovoDebugger(),
    new FileDb()
);
//initialisation de la partie requete HTTP
var HttpClient = function() {
    this.get = function(aUrl, aCallback) {
        var anHttpRequest = new XMLHttpRequest();
        anHttpRequest.onreadystatechange = function() { 
            if (anHttpRequest.readyState == 4 && anHttpRequest.status == 200)
                aCallback(anHttpRequest.responseText);
        }

        anHttpRequest.open( "GET", aUrl, true );            
        anHttpRequest.send( null );
    }
}

// ------------------------------------------------------------------
// APP LOGIC
// ------------------------------------------------------------------

app.setHandler({
    LAUNCH() {
        return this.toIntent('HelloIntent');
    },
     HelloIntent() {
        this.ask('Welcome to Near Me Alexa application ! we help you find your destination  near by and connect with them. ','I dont know if you heard me, welcome to your custom alexa application!');
    },

     SearchForldIntent() {
      
       //console.log(location.latitude+'     '+location.longitude)
       
       var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
       var xhr = new XMLHttpRequest();
       xhr.open('GET', "https://api.ipgeolocation.io/ipgeo?apiKey=6798734ccaa444cdbebfb4c38e3f0d90",false);
       xhr.send();
       var response = JSON.parse(xhr.responseText);
       var location=response;
       xhr.open('GET', "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="+location.latitude+","+location.longitude+"&rankby=distance&type="+this.$inputs.type.value+"&key=AIzaSyCzwnTnE1ZTYwn31SMA24xAS7iNjDN2BT4", false); 
       xhr.send();
       var response = JSON.parse(xhr.responseText);
       console.log(JSON.stringify(response));
       
      var list = [] ;
         for (var i in response.results) {
            
            list[i] = response.results[i].name ;
           
       };    

     
     
       this.ask('We found the following restaurants. \n ' + list + '\n. Which restaurant do you prefer?' ); 
    },
    

   // MyNameIsIntent() {
   //     this.tell('Hey ' + this.$inputs.name.value + ', nice to meet you!');
    //},
});

module.exports.app = app;
